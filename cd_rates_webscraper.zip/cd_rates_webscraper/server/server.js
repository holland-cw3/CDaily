const puppeteer = require('puppeteer'); //Treats loading any webpage as if it were in Chrome

const NFCU = async (page) => {

    return await page.evaluate(() => {
        
        const off = (document.querySelector('tbody:nth-of-type(1)').querySelectorAll('tr')).length + 1;
        const articles = document.querySelectorAll('tr');

        function formatter (start, end, articles){
            return Array.from(articles).slice(start, end).map((article) => { //specific table range
                const term = (article.querySelector('th').innerText).match(/\d+|month|year|Month|Year|Day|day/g)
                TermAmnt = parseInt(term[0]);
                TermType = term[1].toUpperCase();
    
                const tdElements = Array.from(article.querySelectorAll('td'));
                const dataTh = tdElements.map((td) => td.getAttribute('data-th'));
                const rates = tdElements.map((td) => td.innerHTML);
               
               let options = Array(dataTh.length).fill(null);
               for (let i = 0; i < options.length; i++){
                    let Deposit = parseInt(dataTh[i].match(/[0-9]+/g)) * 1000;
                    let APY = rates[i];
                    options[i] = {TermAmnt, TermType, Deposit, APY};
    
               }
                return options;
            })
        }
        let short = (formatter(off, off+4, articles)).flat(1);
        let long = (formatter (off+7, off+10, articles)).flat(1); 
        
        return short.concat(long);
    });

}

const NASA = async (page) => {

    return await page.evaluate(() => {

        const articles = document.querySelectorAll('td');

        let options = Array((articles.length)/4).fill(null);

        for(let i = 0; i <= articles.length - 3; i+=4){
            let term = (articles[i].innerText).match(/\d+|month|year|Month|Year|Day|day/g);
            TermAmnt = parseInt(term[0]);
            TermType = term[1].toUpperCase();

            let Deposit = articles[i + 1].innerText;
            Deposit = (Deposit.match(/\d+/g));
            Deposit =parseInt( Deposit[0] + Deposit[1]);
            let APY = articles[i + 3].innerText;

            options[i/4] = {TermAmnt, TermType, Deposit, APY};
        }
        return options;
    });
}

const CAPFED = async (page) => {

    return await page.evaluate(() => {

        const articles = document.querySelectorAll('td');
        const a2 = document.querySelectorAll('tr');

        let options = Array((a2.length)).fill(null);

        for(let i = 0; i < articles.length - 4; i+=4){
            let term = (articles[i].innerText).match(/\d+|month|year|Month|Year|Day|day/g);
            TermAmnt = parseInt(term[0]);
            TermType = term[1].toUpperCase();

            let Deposit = articles[i + 1].innerText;
            Deposit = (Deposit.match(/\d+/g));
            Deposit = parseInt( Deposit[0] + Deposit[1]);
            let APY = articles[i + 3].innerText;

            options[i/4] = {TermAmnt, TermType, Deposit, APY};
        }   
        return options;
    });
}

const CAPONE = async (page) => {
    await page.waitForSelector('rates-inline');

    return await page.evaluate((Url) => {

        const articles = document.querySelectorAll('td');
        const articles2 = document.querySelectorAll('rates-inline');

        let options = Array((articles.length/3)).fill(null);
        let Deposit = null;

        for(let i = 0; i <= articles.length - 3; i+=3){
            let term = (articles[i].innerText).match(/\d+|month|year|Month|Year|Day|day/g);
            TermAmnt = parseInt(term[0]);
            TermType = term[1].toUpperCase();
            
            let APY = articles2[i/3].innerHTML;
            options[i/3] = {TermAmnt, TermType, Deposit, APY};
        }
        return options;
    });
}

const AIRFRC = async (page) => {

    return await page.evaluate(() => {

        const articles = document.querySelectorAll('td');

        let options = Array((articles.length)/3).fill(null);
        let Deposit = 1000;

        for(let i = 0; i <= articles.length - 3; i+=3){
            let term = (articles[i].innerText).match(/\d+|month|year|Month|Year|Day|day/g);
            TermAmnt = parseInt(term[0]);
            TermType = term[1].toUpperCase();

            let APY = articles[i + 2].innerText;
            [APY ]= APY.match(/[0-9]+\.[0-9]+%/g);
            
            options[i/3] = {TermAmnt, TermType, Deposit, APY};
        }
        return options;
    });
}

const UNITED = async (page) => {

    return await page.evaluate(() => {

        const articles = document.querySelectorAll('td');

        const a3 = (document.querySelectorAll('table')[0].rows.length - 1) * 4;
        const a4 = (document.querySelectorAll('table')[1].rows.length - 1) * 3;

        let options = Array(a3).fill(null);
        let options2 = Array(a4).fill(null);

        for(let i = 0; i < a3 - 3 ; i+=4){
            let term = (articles[i].innerText).match(/\d+|month|year|Month|Year|Day|day/g);
            TermAmnt = parseInt(term[0]);
            TermType = term[1].toUpperCase();

            let Deposit = 500;
            let APY = articles[i + 2].innerText;
            [APY]= APY.match(/[0-9]+\.[0-9]+%/g);
            

            options[i/4] = {TermAmnt, TermType, Deposit, APY};
        }
        for(let i = a3; i <= articles.length - 3 ; i+=3){
            let term = (articles[i].innerText).match(/\d+|month|year|Month|Year|Day|day/g);
            TermAmnt = parseInt(term[0]);
            TermType = term[1].toUpperCase();

            let Deposit = 500;
            let APY = articles[i + 2].innerText;
            [APY]= APY.match(/[0-9]+\.[0-9]+%/g);
            
            options2[i/3] = {TermAmnt, TermType, Deposit, APY};
        }
        return options.concat(options2);

    });
    
}

const LIBERTY = async (page) => {
   
    return await page.evaluate(() => {

        const articles = document.querySelectorAll('td');
        const a2 = document.querySelectorAll('tr');

        let options = Array(a2.length).fill(null);

        for(let i = 0; i < articles.length - 4 ; i+=4){
            let term = (articles[i].innerText).match(/\d+|month|year|Month|Year|Day|day/g);
            TermAmnt = parseInt(term[0]);
            TermType = term[1].toUpperCase();
            let Deposit = 500;
            let APY = articles[i + 2].innerText;
            [APY]= APY.match(/[0-9]+\.[0-9]+%/g);

            options[i/4] = {TermAmnt, TermType, Deposit, APY};
        }
       
        return options;

    });
}

const EVERB = async (page) => {
   
    return await page.evaluate(() => {

        const articles = document.querySelectorAll('td');
        const a2 = document.querySelectorAll('tr');

        let options = Array(a2.length).fill(null);

        for(let i = 0; i <= articles.length - 2 ; i+=2){
            let term = (articles[i].innerText).match(/\d+\.?\d*|month|year|Month|Year|Day|day/g);
            TermAmnt = parseInt(term[0]);
            TermType = term[1].toUpperCase();
            let Deposit = 1000;
            let APY = articles[i + 1].innerText;
            [APY]= APY.match(/[0-9]+\.[0-9]+%/g);

            options[i/2] = {TermAmnt, TermType, Deposit, APY};
        }
       
        return options;

    });
}

const BARCLAYS = async (page) => {
   
    return await page.evaluate(() => {

        const headers = document.querySelectorAll('th');

        const articles = document.querySelectorAll('td');
        const a2 = document.querySelectorAll('tr');

        let options = Array(a2.length).fill(null);

        for(let i = 0; i < articles.length - 2 ; i+=2){
            let term = (headers[(i/2) +3].innerText).match(/\d+|month|year|Month|Year|Day|day/g);
            TermAmnt = parseInt(term[0]);
            TermType = term[1].toUpperCase();
            let Deposit = 0;
            let APY = articles[i + 1].innerText;
            [APY]= APY.match(/[0-9]+\.[0-9]+%/g);

            options[i/2] = {TermAmnt, TermType, Deposit, APY};
        }
       
        return options;

    });
}

const AXOS = async (page) => {
   
    return await page.evaluate(() => {
        const articles = document.querySelectorAll('td');
        const a2 = document.querySelectorAll('tr');

        let options = Array(a2.length).fill(null);
        let Deposit = 1000;

        for(let i = 0; i < articles.length - 4 ; i+=4){
            let term = (articles[i].innerText).match(/\d+|month|year|Month|Year|Day|day/g);
            TermAmnt = parseInt(term[0]);
            TermType = term[1].toUpperCase();
            let APY = articles[i + 1].innerText;
            [APY]= APY.match(/[0-9]+\.[0-9]+%/g);

            options[i/4] = {TermAmnt, TermType, Deposit, APY};
        }
      
        return options;
    });
}



const Funcs = [NFCU, NASA, AIRFRC, CAPONE, CAPFED, UNITED, LIBERTY, EVERB, BARCLAYS, AXOS];

const Main = async () => {
    const Banks = require('./Banks.json');


    try {
      const browser = await puppeteer.launch();
      const page = await browser.newPage();    

      let results = [];

     for (let i = 0; i < Banks.length; i++){ // get data from each site
       await page.goto(Banks[i].url);                   
       let data = (await Funcs[i](page)).filter(function checkNull(opt) {return opt != null;});  
       let url = Banks[i].url;
       let bank = Banks[i].Bank;

       for(let i = 0; i < data.length; i++){
            Object.assign(data[i], { Bank: bank, Url: url}); //add fields from Json
       }
       results = results.concat(data); // append to overall data
       console.log("%s: complete", bank); //indicates that scraping has completed
     }
    
      await page.close();


      require('fs').writeFile('file.json', JSON.stringify(results), (error) => {
        if (error) {
            throw error;
        }
      });
    } catch (error) {
        console.error('Error:', error);
    }
}
Main();